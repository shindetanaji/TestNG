package com.qc.dataprovider;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.common.net.InetAddresses.TeredoInfo;

import net.sourceforge.htmlunit.corejs.javascript.ObjArray;

public class LoginTest {

	WebDriver driver;
	WebElement email;
	WebElement pass;
	WebElement login;
	WebElement logout;

	@BeforeTest
	public void setUp() {
		driver = new FirefoxDriver();
		driver.get("file:///D:/QueueCodes/Software/Selenium/Offline%20Website/index.html");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@BeforeClass
	public void getXpath() {
		email = driver.findElement(By.id("email"));
		pass = driver.findElement(By.id("password"));
		login = driver.findElement(By.id("submit"));
	}

	@BeforeMethod
	public void clearData() {
		email.clear();
		pass.clear();
	}

	@Test(dataProvider = "loginData", description = "Login test case")
	public void doLogin(String uName, String uPass) throws InterruptedException {
		email.sendKeys(uName);
		pass.sendKeys(uPass);
		login.click();
		Thread.sleep(2000);
	}

	@DataProvider(name = "loginData")
	public Object[][] testData() {

		return new Object[][] { 
				new Object[] { "", "" }, 
				new Object[] { "", "123456" },
				new Object[] { "queuecodes@gmail.com", "" }, 
				new Object[] { "queuecodes", "12345" },
				new Object[] { "queuecodes@gmail.com", "12345" }, 
				new Object[] { "queueu", "123456" },
				new Object[] { "queuecodes@gmail.com", "123456" }

		};

	}

	@AfterMethod
	public void doLogout() {
		String title = driver.getTitle();
		if (title.equalsIgnoreCase("Queue Codes | Dashboard")) {
			logout = driver.findElement(By.xpath(".//*[@id='hlogout']/a"));
			logout.click();
		} 
	}
	
	@AfterTest
	public void tearDown() {
		driver.close();
	}

}
