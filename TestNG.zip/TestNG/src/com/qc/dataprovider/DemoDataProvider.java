package com.qc.dataprovider;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DemoDataProvider {

	@Test(dataProvider = "test")
	public void testData(int tcNo, String uName, String uPass, String tcMsg) {
		System.out.println("Test case no: " + tcNo);
		System.out.println("UserName: " + uName);
		System.out.println("Password: " + uPass);
		System.out.println("Message: " + tcMsg);
		System.out.println("---------------------");
	}

	@DataProvider(name="test")
	public Object[][] sampleData(){
		return new Object[][] {
			new Object[] {1,"queuecodes@gmail.com", "12345", "Valid test data"},
			new Object[] {2,"", "", "Blank test data"}
		};
	}

}
