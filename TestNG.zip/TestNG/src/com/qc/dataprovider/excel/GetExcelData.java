package com.qc.dataprovider.excel;

import java.io.FileInputStream;
import java.io.IOException;

import org.testng.annotations.DataProvider;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class GetExcelData {

	@DataProvider(name = "loginData")
	public Object[][] getData() throws BiffException, IOException {
		FileInputStream fis = new FileInputStream("ReadData.xls");
		Workbook wbook = Workbook.getWorkbook(fis);
		Sheet sheet = wbook.getSheet("Sheet1");

		int rows = sheet.getRows();
		int col = sheet.getColumns();

		String testData[][] = new String[rows - 1][col];

		int count = 0;

		for (int i = 1; i < rows; i++) {
			for (int j = 0; j < col; j++) {
				Cell cell = sheet.getCell(j, i);
				testData[count][j] = cell.getContents();
			}
			count++;
		}
		fis.close();
		return testData;

	}

}
