package com.qc.dataprovider.excel;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class LoginTestCase extends GetExcelData {

	ExtentReports extent;
	ExtentTest logger;
	WebDriver driver;
	WebElement email;
	WebElement pass;
	WebElement login;
	WebElement logout;

	@BeforeSuite
	public void setUp() {
		driver = new FirefoxDriver();
		driver.get("file:///D:/QueueCodes/Software/Selenium/Offline%20Website/index.html");
		// driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@BeforeTest
	public void startTest() {
		extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/ExtentReport.html", true);
		extent.addSystemInfo("Host Name", "Queue codes technology").addSystemInfo("Environment", "Automation testing")
				.addSystemInfo("User Name", "Queue");
		extent.loadConfig(new File(System.getProperty("user.dir") + "/extent-config.xml"));
	}

	@BeforeClass
	public void getXpath() {
		email = driver.findElement(By.id("email"));
		pass = driver.findElement(By.id("password"));
		login = driver.findElement(By.id("submit"));
	}

	@BeforeMethod
	public void clearData() {
		email.clear();
		pass.clear();
	}

	@Test(dataProvider = "loginData", description = "Login test case")
	public void doLogin(String uName, String uPass) throws InterruptedException {
		logger = extent.startTest("Login test");
		email.sendKeys(uName);
		pass.sendKeys(uPass);
		login.click();
		Thread.sleep(2000);
		logger.log(LogStatus.PASS, "Queue codes login");
	}

	@AfterMethod
	public void doLogout() {
		String title = driver.getTitle();
		if (title.equalsIgnoreCase("Queue Codes | Dashboard")) {
			logout = driver.findElement(By.xpath(".//*[@id='hlogout']/a"));
			logout.click();
		}
		extent.endTest(logger);
	}

	@AfterTest
	public void endReport() {
		extent.flush();
		extent.close();
	}
	
	@AfterSuite
	public void tearDown() {
		driver.close();
	}

}
