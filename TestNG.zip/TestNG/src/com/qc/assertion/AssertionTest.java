package com.qc.assertion;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AssertionTest {

	@Test
	public void doAssert() {
		Assert.assertEquals(4, 4);
		System.out.println("in doAssert method");
	}

	@Test
	public void doAssert1() {
		Assert.assertEquals(4, 3);
		System.out.println("in doAssert1 method");
	}

}
