package com.qc.assertion;

import org.testng.annotations.Test;

public class A {

	@Test
	public void doTest() {
		System.out.println("Tested");
	}

}
