package com.qc.assertion;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertExample {

	SoftAssert sa = new SoftAssert();

	@Test
	public void doTest() {
		System.out.println("1");
		sa.assertEquals(4, 4);
		System.out.println("2");
		sa.assertEquals(3, 4);
		System.out.println("3");
		sa.assertEquals(5, 5);
		System.out.println("4");
		sa.assertAll();
	}

}
