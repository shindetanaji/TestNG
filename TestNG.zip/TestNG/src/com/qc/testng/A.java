package com.qc.testng;

import org.testng.annotations.Test;

public class A {

	@Test
	public void m1() {
		System.out.println("Test case 1");
	}
	
}
